var searchData=
[
  ['level_5f1_0',['level_1',['../_assignment2_doc_8c.html#a3a9af14331bd8305bc2f1250208fc7b2',1,'Assignment2Doc.c']]],
  ['level_5f2_1',['level_2',['../_assignment2_doc_8c.html#a918f2d885d3e2adfd1b71629b9749354',1,'Assignment2Doc.c']]],
  ['level_5f3_2',['level_3',['../_assignment2_doc_8c.html#a7f35cd324f92b9adddd8da64e28bcb38',1,'Assignment2Doc.c']]],
  ['level_5f4_3',['level_4',['../_assignment2_doc_8c.html#a7797658aa06a12295a51edf1cb0bc215',1,'Assignment2Doc.c']]],
  ['level_5fnumber_4',['level_number',['../_assignment2_doc_8c.html#a564abc27b126ef392d7b1d74b3a0461f',1,'Assignment2Doc.c']]],
  ['level_5fselection_5',['level_selection',['../_assignment2_doc_8c.html#aa21f29200d57b83df365d0bd9a6e67e8',1,'Assignment2Doc.c']]],
  ['lives_6',['lives',['../_assignment2_doc_8c.html#ac1d68ef9a5dd304c5015e07af7f2bb19',1,'Assignment2Doc.c']]],
  ['load_5flevel_7',['load_level',['../_assignment2_doc_8c.html#adb0b2ddbf83551d2532ec60ee3378b82',1,'Assignment2Doc.c']]]
];
