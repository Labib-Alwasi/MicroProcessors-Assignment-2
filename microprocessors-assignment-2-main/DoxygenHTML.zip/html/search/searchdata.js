var indexSectionsWithContent =
{
  0: "aceghilmnpsw",
  1: "w",
  2: "a",
  3: "aceghilmpsw",
  4: "aghilmnsw",
  5: "inw",
  6: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

