var searchData=
[
  ['search_0',['search',['../_assignment2_doc_8c.html#a798afd46f5406092e0c81625e5492c46',1,'Assignment2Doc.c']]],
  ['set_5finput_1',['set_input',['../_assignment2_doc_8c.html#a9b35dd00320f3346be6815ae16e305f3',1,'Assignment2Doc.c']]],
  ['set_5finput_5farray_2',['set_input_array',['../_assignment2_doc_8c.html#a519e7fad6a1cf466e9957f3e936513a4',1,'Assignment2Doc.c']]],
  ['set_5frgb_3',['set_rgb',['../_assignment2_doc_8c.html#a79b7b7b8863c8121e0d9aa5a36c31005',1,'Assignment2Doc.c']]],
  ['start_5ftime_4',['start_time',['../_assignment2_doc_8c.html#ab0e0cd1f602c8fd7aeae8c9224bb2e49',1,'Assignment2Doc.c']]],
  ['start_5ftimer_5',['start_timer',['../_assignment2_doc_8c.html#aaedac22c55880495505bf375e0e132c1',1,'Assignment2Doc.c']]]
];
