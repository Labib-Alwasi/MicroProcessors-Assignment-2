var searchData=
[
  ['check_5fpattern_0',['check_pattern',['../_assignment2_doc_8c.html#af7ebf5e674f7cd4ee3ad0af6b8e80842',1,'Assignment2Doc.c']]]
];
