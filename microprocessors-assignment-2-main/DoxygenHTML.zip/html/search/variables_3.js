var searchData=
[
  ['item_0',['item',['../_assignment2_doc_8c.html#a75cc046d74ea8216422d4d15445e8c4e',1,'Assignment2Doc.c']]]
];
