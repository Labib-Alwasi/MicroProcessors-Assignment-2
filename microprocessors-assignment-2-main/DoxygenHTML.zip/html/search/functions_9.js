var searchData=
[
  ['search_0',['search',['../_assignment2_doc_8c.html#a798afd46f5406092e0c81625e5492c46',1,'Assignment2Doc.c']]],
  ['set_5finput_1',['set_input',['../_assignment2_doc_8c.html#a9b35dd00320f3346be6815ae16e305f3',1,'Assignment2Doc.c']]],
  ['set_5frgb_2',['set_rgb',['../_assignment2_doc_8c.html#a79b7b7b8863c8121e0d9aa5a36c31005',1,'Assignment2Doc.c']]],
  ['start_5ftimer_3',['start_timer',['../_assignment2_doc_8c.html#aaedac22c55880495505bf375e0e132c1',1,'Assignment2Doc.c']]]
];
