var searchData=
[
  ['level_5fnumber_0',['level_number',['../_assignment2_doc_8c.html#a564abc27b126ef392d7b1d74b3a0461f',1,'Assignment2Doc.c']]],
  ['level_5fselection_1',['level_selection',['../_assignment2_doc_8c.html#aa21f29200d57b83df365d0bd9a6e67e8',1,'Assignment2Doc.c']]],
  ['lives_2',['lives',['../_assignment2_doc_8c.html#ac1d68ef9a5dd304c5015e07af7f2bb19',1,'Assignment2Doc.c']]]
];
