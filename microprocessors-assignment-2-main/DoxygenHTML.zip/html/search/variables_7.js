var searchData=
[
  ['set_5finput_5farray_0',['set_input_array',['../_assignment2_doc_8c.html#a519e7fad6a1cf466e9957f3e936513a4',1,'Assignment2Doc.c']]],
  ['start_5ftime_1',['start_time',['../_assignment2_doc_8c.html#ab0e0cd1f602c8fd7aeae8c9224bb2e49',1,'Assignment2Doc.c']]]
];
