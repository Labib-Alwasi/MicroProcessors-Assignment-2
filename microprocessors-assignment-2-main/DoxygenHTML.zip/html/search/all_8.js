var searchData=
[
  ['num_5fmorse_0',['num_morse',['../_assignment2_doc_8c.html#a1d65664f60c40e75e1fb1e1da13ca1c6',1,'Assignment2Doc.c']]],
  ['num_5fpixels_1',['NUM_PIXELS',['../_assignment2_doc_8c.html#a893011783fefc21f30baf08142cd3c35',1,'Assignment2Doc.c']]]
];
