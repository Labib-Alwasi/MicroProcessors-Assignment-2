var searchData=
[
  ['is_5frgbw_0',['IS_RGBW',['../_assignment2_doc_8c.html#a493b9b7cc0c4de9e5d832a5b9c8fe0f0',1,'Assignment2Doc.c']]]
];
