var searchData=
[
  ['num_5fpixels_0',['NUM_PIXELS',['../_assignment2_doc_8c.html#a893011783fefc21f30baf08142cd3c35',1,'Assignment2Doc.c']]]
];
