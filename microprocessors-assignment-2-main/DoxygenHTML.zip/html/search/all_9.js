var searchData=
[
  ['print_5flevel_5fstats_0',['print_level_stats',['../_assignment2_doc_8c.html#a69e8cbae10ce38be0dadb3afe4b4c866',1,'Assignment2Doc.c']]],
  ['project_20description_1',['Project Description',['../index.html',1,'']]]
];
