var searchData=
[
  ['welcome_5fmessage_0',['welcome_message',['../_assignment2_doc_8c.html#ae9cf07cdcd9e6084bf86b1ffa5e031ba',1,'Assignment2Doc.c']]]
];
