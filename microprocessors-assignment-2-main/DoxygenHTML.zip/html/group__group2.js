var group__group2 =
[
    [ "LevelFunctions", "group__group3.html", "group__group3" ],
    [ "check_pattern", "group__group2.html#gaf7ebf5e674f7cd4ee3ad0af6b8e80842", null ],
    [ "game_over_failure", "group__group2.html#gaa37cec752bcec02e6f88b87c77890dfa", null ],
    [ "game_over_success", "group__group2.html#ga5a772912b4007d869e32e25d9fefd2e6", null ],
    [ "generate_random_character", "group__group2.html#ga77eb35b468eeb932d3418b662db62aee", null ],
    [ "generate_random_word", "group__group2.html#ga1a2e4b41377e7b4e61f1df811187fade", null ],
    [ "load_level", "group__group2.html#gaf7f03d8f009712fc98b38bd741bf0b2f", null ],
    [ "print_level_stats", "group__group2.html#ga69e8cbae10ce38be0dadb3afe4b4c866", null ],
    [ "set_rgb", "group__group2.html#ga79b7b7b8863c8121e0d9aa5a36c31005", null ],
    [ "welcome_message", "group__group2.html#gae9cf07cdcd9e6084bf86b1ffa5e031ba", null ],
    [ "game_status", "group__group2.html#ga124e91c1f635a28df553637a571ea92f", null ],
    [ "level_number", "group__group2.html#ga564abc27b126ef392d7b1d74b3a0461f", null ],
    [ "level_selection", "group__group2.html#gaa21f29200d57b83df365d0bd9a6e67e8", null ],
    [ "lives", "group__group2.html#gac1d68ef9a5dd304c5015e07af7f2bb19", null ],
    [ "start_time", "group__group2.html#gab0e0cd1f602c8fd7aeae8c9224bb2e49", null ]
];