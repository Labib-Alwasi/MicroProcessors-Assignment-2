var structwords__hash__table =
[
    [ "morse", "structwords__hash__table.html#a86337d0f40fc9e9e93e5a122fb6de581", null ],
    [ "word", "structwords__hash__table.html#ac00a4258bfdabd98aca279382135ec92", null ]
];